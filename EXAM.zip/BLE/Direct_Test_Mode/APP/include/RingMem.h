/********************************** (C) COPYRIGHT *******************************
* File Name          : RingMem.h
* Author             : WCH
* Version            : V1.0
* Date               : 2025/04/28
* Description        : 
            
*******************************************************************************/

/*********************************************************************
 * INCLUDES
 */

/*********************************************************************
 * CONSTANTS
 */

#ifndef RINGMEM_H
#define RINGMEM_H

#ifndef SUCCESS
#define SUCCESS	0
#endif

/*********************************************************************
 * TYPEDEFS
 */
 
typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;
typedef unsigned long   uint32_t;

//�������ṹ��
typedef struct 
{
         uint8_t   *pData;		    //�������׵�ַ
         uint8_t 	 *pWrite;           //дָ��
         uint8_t 	 *pRead;		    //��ָ��
         uint8_t   *pEnd;			    //������ĩ��ַ
volatile uint32_t  RemanentLen;       //ʣ��ռ��С
volatile uint32_t  CurrentLen;        //���ÿռ��С
volatile uint32_t  MaxLen;      	    //�ܿռ��С
}RingMemParm;

/*********************************************************************
 * Global Variables
 */

/*********************************************************************
 * FUNCTIONS
 */

extern void RingMemInit( RingMemParm *Parm, uint8_t *StartAddr, uint32_t MaxLen );

extern uint8_t RingMemWrite( RingMemParm *Parm, uint8_t *pData, uint32_t len );

extern uint8_t RingMemRead( RingMemParm *Parm, uint8_t *pData, uint32_t len );

extern uint8_t RingMemCopy( RingMemParm *Parm, uint8_t *pData, uint32_t len );

extern uint8_t RingMemDelete( RingMemParm *Parm, uint32_t len );

extern uint8_t RingAddInStart( RingMemParm *Parm, uint8_t *pData, uint32_t len );

extern uint8_t RingReturnSingleData( RingMemParm *Parm, uint32_t Num );

extern int __wrap_memcmp (void *src, const void * dst, size_t size);

extern void * __wrap_memset (void *src, int value, size_t size);
/*********************************************************************
*********************************************************************/

#endif
