/********************************** (C) COPYRIGHT *******************************
 * File Name          : app_usb.h
 * Author             : WCH
 * Version            : V1.1
 * Date               : 2022/01/19
 * Description        :
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for 
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/

#ifndef _APP_USB_H
#define _APP_USB_H

#ifdef __cplusplus
extern "C" {
#endif



extern void app_usb_init(void);
extern uint8_t USBSendData(uint8_t *buf, uint16_t len);

/*********************************************************************
*********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* _APP_USB_H */
